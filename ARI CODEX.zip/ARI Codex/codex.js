/* THE ARI CODEX — shared navigation + pager */
(function () {
  var CONSTITUTION_HREF = "../AXION Constitution/index.html";
  var BLUEPRINT_HREF = "../ARI Blueprint/ARI Developer Blueprint.html";
  var BOOKS = [
    { file: "index.html",   num: "🍎",  title: "Frontmatter", group: "The Codex" },
    { file: "book-01.html", num: "I",   title: "The Anatomy of ARI", group: "The Books" },
    { file: "book-02.html", num: "II",  title: "The Genome" },
    { file: "book-03.html", num: "III", title: "The Brain" },
    { file: "book-04.html", num: "IV",  title: "The Nervous System" },
    { file: "book-05.html", num: "V",   title: "The Organs" },
    { file: "book-06.html", num: "VI",  title: "The Agent Society" },
    { file: "book-07.html", num: "VII", title: "The Venture Studio" },
    { file: "book-08.html", num: "VIII",title: "Civilization Intelligence" },
    { file: "book-09.html", num: "IX",  title: "The Embodied Organization" },
    { file: "book-10.html", num: "X",   title: "The Embodiments" },
    { file: "book-11.html", num: "XI",  title: "The Evolution" },
    { file: "book-12.html", num: "XII", title: "Appendices" }
  ];

  var current = (location.pathname.split("/").pop() || "index.html");
  var idx = BOOKS.findIndex(function (b) { return b.file === decodeURIComponent(current); });
  if (idx < 0) idx = 0;

  var nav = document.getElementById("codex-nav");
  if (nav) {
    var html = "";
    BOOKS.forEach(function (b, i) {
      if (b.group) html += '<div class="nav-group-label">' + b.group + "</div>";
      html += '<a href="' + b.file + '"' + (i === idx ? ' class="active"' : "") + ">" +
        '<span class="n">' + b.num + "</span><span>" + b.title + "</span></a>";
    });
    nav.innerHTML = html;

    var back = document.createElement("a");
    back.href = CONSTITUTION_HREF;
    back.className = "codex-back-link";
    back.innerHTML = "← Back to the Constitution";
    nav.parentNode.insertBefore(back, nav);

    var blueprint = document.createElement("a");
    blueprint.href = BLUEPRINT_HREF;
    blueprint.className = "codex-back-link codex-blueprint-link";
    blueprint.innerHTML = "⚙ Developer Blueprint";
    nav.parentNode.insertBefore(blueprint, nav);
  }

  var pager = document.getElementById("codex-pager");
  if (pager) {
    var html2 = "";
    if (idx > 0) {
      var p = BOOKS[idx - 1];
      html2 += '<a class="prev" href="' + p.file + '"><span class="dir">← Previous</span>' + (p.num !== "🍎" ? "Book " + p.num + " — " : "") + p.title + "</a>";
    }
    if (idx < BOOKS.length - 1) {
      var n = BOOKS[idx + 1];
      html2 += '<a class="next" href="' + n.file + '"><span class="dir">Next →</span>' + (n.num !== "🍎" ? "Book " + n.num + " — " : "") + n.title + "</a>";
    }
    pager.innerHTML = html2;
  }
})();
